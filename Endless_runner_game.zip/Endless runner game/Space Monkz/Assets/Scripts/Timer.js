﻿#pragma strict

var timer : float = 10.0;
 
function Update () 
{
    timer -= Time.deltaTime;
     
    if(timer <= 0)
    {
        Application.LoadLevel(1);

        timer = 0;
    }
}

function OnGUI ()
{
    GUI.Box(new Rect(500, 20, 50, 20),"" + timer.ToString("0"));
}